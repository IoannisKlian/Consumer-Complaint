import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class DisplayMessages implements Runnable {
	Scanner inputReader = new Scanner(System.in);
	
	/* For writing to socket */
	PrintStream outToServer;         
	/* For reading from user */
	BufferedReader inFromUser;                  
	/* Hold user input */
	String sentence = null, modifiedSentence = null;

	String nameOfClient;
	
	public DisplayMessages(Socket clientSocket,String name) throws IOException{
		
        nameOfClient = name;

        try {
        	
			inFromUser = new BufferedReader( new InputStreamReader( System.in ) ); 
			/* Create a writing buffer to the socket */
			outToServer = new PrintStream( clientSocket.getOutputStream(), true); 
        	
			
        } catch (UnknownHostException e) {
			System.out.println("Can not locate host/port");
			return;
        } catch (IOException e) {
			System.out.println("Could not establish connection");
			return;
        }
		
		
	}
	@Override
	public void run() {

		try {
			while(true){
				/* Send the message to server */
				sentence = inFromUser.readLine();
				outToServer.println( nameOfClient+": "+sentence );

			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			        
		

	}

}
